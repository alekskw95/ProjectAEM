﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.DataVisualization.Charting;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfAppAEM
{
    /// <summary>
    /// Interaction logic for UserControlDHDiagram.xaml
    /// </summary>
    public partial class UserControlDHDiagram : UserControl
    {

        public int numberP;
        public int numberG;
        public int[] tableValueDH;
        public List<Tuple<int, int>> mydictDH;


        public UserControlDHDiagram()
        {
            InitializeComponent();

            mydictDH = new List<Tuple<int, int>>();

        }

        private void runDH()
        {
            numberP = Convert.ToInt32(TbDHP.Text);
            int p = numberP;

            int inputNumber = p - 1;



            int gg = Convert.ToInt32(G.Text);

            for (int i = 1; i < inputNumber; i++)
            {
                System.Numerics.BigInteger bigInt = System.Numerics.BigInteger.Pow(gg, i) % p;
                int x = (int)bigInt;
                mydictDH.Add(new Tuple<int, int>(i, x));
            }
        }


        private void BtnDHStart_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                BtnDHStart.IsEnabled = false;

                runDH();

                ScatterSeries series;

                List<Point> listPoints = new List<Point>();

                foreach (var item in mydictDH)
                {
                    listPoints.Add(new Point(item.Item1, item.Item2));
                }


                series = new ScatterSeries();
                lineAx.Maximum = numberP + 1;
                series.DependentValuePath = "Y";
                series.IndependentValuePath = "X";
                series.ItemsSource = listPoints;

                chart1.Series.Add(series);
            }
            catch
            {
                MessageBox.Show("Nie podano wartosci!!!");
                BtnDHStart.IsEnabled = true;
            }
        }


    }
}
