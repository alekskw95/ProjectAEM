﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Security.Cryptography;
using System.Collections.ObjectModel;
using System.Windows.Controls.DataVisualization.Charting;
using System.Numerics;
using System.Data;


namespace WpfAppAEM
{
    /// <summary>
    /// Interaction logic for UserControlDiffieHellman.xaml
    /// </summary>
    public partial class UserControlDiffieHellman : UserControl
    {

        public DataTable dt;
        public DataColumn dc;

        public UserControlDiffieHellman()
        {
            InitializeComponent();

        }

        private void BtnDHStart_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                BtnDHStart.IsEnabled = false;

                int p = Convert.ToInt32(TbDHP.Text);
                

                dt = new DataTable();
                dc = new DataColumn();


                DataGridTextColumn dgColumn;

                for (int i = 0; i < p; i++)
                {
                    dc = new DataColumn(i.ToString());
                    dt.Columns.Add(dc);


                    if (i == 0)
                    {
                        dgColumn = new DataGridTextColumn
                        {
                            Header = "K/G",
                            Width = 40,
                            Binding = new Binding(dt.Columns[i].ColumnName)

                        };

                    }
                    else
                    {
                        dgColumn = new DataGridTextColumn
                        {
                            Header = dt.Columns[i].ColumnName,
                            Width = 40,
                            Binding = new Binding(dt.Columns[i].ColumnName)

                        };

                    }

                    if (i > 0)
                    {
                        Style columnStyle = new Style(typeof(TextBlock));
                        Trigger backgroundColorTrigger = new Trigger
                        {
                            Property = TextBlock.TextProperty,
                            Value = "1"
                        };
                        backgroundColorTrigger.Setters.Add(
                            new Setter(
                                TextBlock.BackgroundProperty,
                                new SolidColorBrush(Colors.Red)));
                        columnStyle.Triggers.Add(backgroundColorTrigger);
                        dgColumn.ElementStyle = columnStyle;
                    }
                    dataGrid1.Columns.Add(dgColumn);
                }

                for (int i = 1; i < p; i++)
                {
                    dt.Rows.Add(i, "");
                }

                for (int i = 1; i < p; i++)
                {

                    for (int j = 1; j < p; j++)
                    {
                        BigInteger potega = System.Numerics.BigInteger.Pow(j, i) % p;

                        if (potega == 1)
                        {
                            dt.Rows[i - 1][j] = potega;
                        }
                        else
                        {
                            dt.Rows[i - 1][j] = potega;
                        }
                    }
                }


                dataGrid1.ItemsSource = dt.DefaultView;

                BrushesColumn(p);

                dataGrid1.ItemsSource = dt.DefaultView;

                for (int i = 0; i < p; i++)
                {
                    dataGrid1.Columns.RemoveAt(p);
                }
            }
            catch
            {
                MessageBox.Show("Nie podano wartosci!!!");
                BtnDHStart.IsEnabled = true;
            }
        }


        public void BrushesColumn(int inputN)
        {
            List<int> listaKolumn = new List<int>();
            List<int> listaKolumn2 = new List<int>();

            int jakaKolumna = 0;
            int licznik = 0;

            for (int i = 1; i < inputN; i++) 
            {
                int kol = i;

                for (int j = 1; j < inputN-1; j++)
                {
                    var it = dt.Rows[j - 1][kol];

                    int modulo = Convert.ToInt32(it); 

                    if (modulo == 1)
                    {
                        licznik++;
                    }

                }
                if (licznik == 0)
                {
                    listaKolumn.Add(kol);
                }
                else
                {
                    listaKolumn2.Add(kol);
                }
                licznik = 0;
            }

            if (listaKolumn.Count() != 0)
            {
                for (int z = 0; z < listaKolumn.Count; z++)
                {
                    jakaKolumna = listaKolumn[z];

                    
                    var desiredColor = new SolidColorBrush(Colors.LimeGreen);

                    dataGrid1.Columns[jakaKolumna].CellStyle = new Style(typeof(DataGridCell));
                    dataGrid1.Columns[jakaKolumna].CellStyle.Setters.Add(new Setter(BackgroundProperty, desiredColor));

                    
                }

            }

            if (listaKolumn2.Count() != 0)
            {
                for (int z = 0; z < listaKolumn2.Count; z++)
                {
                    jakaKolumna = listaKolumn2[z];

                    var desiredColor = new SolidColorBrush(Colors.Gold);

                    dataGrid1.Columns[jakaKolumna].CellStyle = new Style(typeof(DataGridCell));
                    dataGrid1.Columns[jakaKolumna].CellStyle.Setters.Add(new Setter(BackgroundProperty, desiredColor));


                }
            }
        }


    }
}
