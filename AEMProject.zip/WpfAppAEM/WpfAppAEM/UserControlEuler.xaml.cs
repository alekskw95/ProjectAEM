﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.DataVisualization.Charting;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfAppAEM
{
    /// <summary>
    /// Interaction logic for UserControlEuler.xaml
    /// </summary>
    public partial class UserControlEuler : UserControl
    {
        public int valueE = 0;
        public int[] tableValueEuler;
        public Dictionary<int, int> mydictEuler;

        public UserControlEuler()
        {
            InitializeComponent();


            mydictEuler = new Dictionary<int, int>();

        }

        public class EulerAlgorithm
        {

            static void SieveOfEratosthenes(int n, bool[] prime, bool[] primesquare, int[] a)
            {

                for (int i = 2; i <= n; i++)
                    prime[i] = true;


                for (int i = 0; i < ((n * n) + 1); i++)
                    primesquare[i] = false;

   
                prime[1] = false;

                for (int p = 2; p * p <= n; p++)
                {

                    if (prime[p] == true)
                    {
                        for (int i = p * 2; i <= n; i += p)
                            prime[i] = false;
                    }
                }

                int j = 0;
                for (int p = 2; p <= n; p++)
                {
                    if (prime[p])
                    {
                        a[j] = p;

                        primesquare[p * p] = true;
                        j++;
                    }
                }
            }

            public int countDivisors(int n)
            {

                if (n == 1)
                    return 1;

                bool[] prime = new bool[n + 1];
                bool[] primesquare = new bool[(n * n) + 1];


                int[] a = new int[n];


                SieveOfEratosthenes(n, prime, primesquare, a);


                int ans = 1;

                for (int i = 0; ; i++)
                {

                    if (a[i] * a[i] * a[i] > n)
                        break;

                    int cnt = 1;


                    while (n % a[i] == 0)
                    {
                        n = n / a[i];

             
                        cnt = cnt + 1;
                    }

                    ans = ans * cnt;
                }


                if (prime[n])
                    ans = ans * 2;


                else if (primesquare[n])
                    ans = ans * 3;

 
                else if (n != 1)
                    ans = ans * 4;

                return ans; 
            }

        }
        public void RunEuler(int n)
        {
            valueE = n;

            EulerAlgorithm mobiusGFG = new EulerAlgorithm();

            for (int i = 1; i <= valueE; i++)
            {
                mydictEuler.Add(i, mobiusGFG.countDivisors(i));
            }
        }

        public ObservableCollection<CDFPlotEuler> CDFPlotCollectionEuler { get; set; }

        public class CDFPlotEuler : ObservableCollection<Point>
        {
            public CDFPlotEuler(int r, int t)
            {
                Add(new Point { X = r, Y = t });
            }
        }

        private void BtnEulerStart_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                BtnEulerStart.IsEnabled = false;

                RunEuler(int.Parse(TbEulerN.Text));


                LineSeries series;


                CDFPlotCollectionEuler = new ObservableCollection<CDFPlotEuler>();

                for (int i = 1; i <= valueE; i++)
                {
                    int z = mydictEuler[i];
                    CDFPlotCollectionEuler.Add(new CDFPlotEuler(i, z));
                }


                series = new LineSeries();
                series.DependentValuePath = "Y";
                series.IndependentValuePath = "X";
                series.ItemsSource = CDFPlotCollectionEuler;
                chart2.Series.Add(series);
            }
            catch
            {
                MessageBox.Show("Nie podano liczby");
                BtnEulerStart.IsEnabled = true;
            }


        }

        private void BtnEulerPokaz_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int valueShow = Convert.ToInt32(TbEulerNumber.Text);
                int valueToShow = 0;
                TbEulerNumber.Clear();


                foreach (KeyValuePair<int, int> r in mydictEuler)
                {
                    if (r.Key == valueShow)
                    {
                        valueToShow = r.Value;
                    }
                }


                TbEulerNumberShow.Background = Brushes.Green;
                TbEulerNumberShow.Text = valueToShow.ToString();
            }
            catch
            {
                MessageBox.Show("Podaj liczbe!!!");
            }
            
        }


        private void TbEulerNumber_MouseEnter(object sender, MouseEventArgs e)
        {
            TbEulerNumberShow.Background = Brushes.LightBlue;
            TbEulerNumberShow.Clear();
        }
    }
}
