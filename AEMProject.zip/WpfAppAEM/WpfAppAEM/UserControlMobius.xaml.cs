﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.DataVisualization.Charting;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfAppAEM
{
    /// <summary>
    /// Interaction logic for UserControlMobius.xaml
    /// </summary>
    public partial class UserControlMobius : UserControl
    {
        public int value = 0;
        public int[] tableValueMobius;
        public Dictionary<int, int> mydict;
  

        public UserControlMobius()
        {
            InitializeComponent();

            mydict = new Dictionary<int, int>();

           

        }


        public class MobiusAlgorithmSimpleVersion
        {

            static bool isPrime(int n)
            {
                if (n == 2)
                    return true;

                if (n % 2 == 0)
                    return false;
                for (int i = 3; i * i <= n / 2; i += 2)
                    if (n % i == 0)
                        return false;
                return true;
            }

            public int mobius(int N)
            {

   
                if (N == 1)
                    return 1;

                int p = 0;
                for (int i = 2; i <= N; i++)
                {
                    if (N % i == 0 && isPrime(i))
                    {

                        if (N % (i * i) == 0)
                            return 0;
                        else
                            p++;
                    }
                }

               
                return (p % 2 != 0) ? -1 : 1;
            }
        }

        public class MobiusAlgorithm
        {

           
            public int mobius(int n)
            {
                if (n == 1) return 1;
                else if (n == 2) return -1;

                int p = 0;

                
                if (n % 2 == 0)
                {
                    n = n / 2;
                    p++;

                    
                    if (n % 2 == 0)
                        return 0;
                }

             
                for (int i = 3; i <= Math.Sqrt(n); i = i + 2)
                {
                    
                    if (n % i == 0)
                    {
                        n = n / i;
                        p++;

                
                        if (n % i == 0)
                            return 0;
                    }
                }

                return (p % 2 == 0) ? -1 : 1;
            }

  
        }


        public void RunMobius(int n)
        {
            value = n;


            MobiusAlgorithm mobiusAlg = new MobiusAlgorithm();


            for (int i = 1; i <= value; i++)
            {
                mydict.Add(i, mobiusAlg.mobius(i));
            }
        }

        public ObservableCollection<CDFPlotMobius> CDFPlotCollectionMobius { get; set; }

        public class CDFPlotMobius : ObservableCollection<Point>
        {
            public CDFPlotMobius(int r, int t)
            {
                Add(new Point { X = r, Y = t});
            }
        }

        private void BtnMobiusStart_Click(object sender, RoutedEventArgs e)
        {
           
            try
            {
                BtnMobiusStart.IsEnabled = false;

                RunMobius(int.Parse(TbMobiusN.Text));


                ScatterSeries series;


                CDFPlotCollectionMobius = new ObservableCollection<CDFPlotMobius>();

                for (int i = 1; i <= value; i++)
                {
                    int z = mydict[i];
                    CDFPlotCollectionMobius.Add(new CDFPlotMobius(i, z));
                }


                series = new ScatterSeries();
                series.DependentValuePath = "Y";
                series.IndependentValuePath = "X";
                series.ItemsSource = CDFPlotCollectionMobius;
                chart1.Series.Add(series);
            }
            catch
            {
                MessageBox.Show("Nie podano wartosci!!!");
                BtnMobiusStart.IsEnabled = true;
            }


        }

        private void BtnMobiusShow_Click(object sender, RoutedEventArgs e)
        {
            WindowMobiusData windowsMobiusdata = new WindowMobiusData(mydict, value);
            windowsMobiusdata.Show();
        }

        private void BtnMobiusPokaz_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int valueShow = Convert.ToInt32(TbMobiusNumber.Text);
                int valueToShow = 0;
                TbMobiusNumber.Clear();


                foreach (KeyValuePair<int, int> r in mydict)
                {
                    if (r.Key == valueShow)
                    {
                        valueToShow = r.Value;
                    }
                }


                TbMobiusNumberShow.Background = Brushes.Green;
                TbMobiusNumberShow.Text = valueToShow.ToString();
            }
            catch
            {
                MessageBox.Show("Podaj liczbe!!!");
            }
        }


        private void TbMobiusNumber_MouseEnter(object sender, MouseEventArgs e)
        {
            TbMobiusNumberShow.Background = Brushes.LightBlue;
            TbMobiusNumberShow.Clear();
        }
    }
}
