﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfAppAEM
{
    /// <summary>
    /// Interaction logic for WindowMobiusData.xaml
    /// </summary>
    public partial class WindowMobiusData : Window
    {
        public WindowMobiusData()
        {
            InitializeComponent();
        }

        public Dictionary<int, int> dictWindowM;
        public DataTable dt;
        public DataColumn dc;
        public int tS, tD, tW;

        public List<int> listN1;
        public List<int> listN2;
        public List<int> listN3;

        public WindowMobiusData(Dictionary<int, int> dictFromMobius, int v)
        {
            InitializeComponent();

            dictWindowM = new Dictionary<int, int>();

            dictWindowM = dictFromMobius;

            listN1 = new List<int>();
            listN2 = new List<int>();
            listN3 = new List<int>();

            dt = new DataTable();
            dc = new DataColumn();

            dc = new DataColumn("t1");
            dt.Columns.Add(dc);
            dc = new DataColumn("t2");
            dt.Columns.Add(dc);
            dc = new DataColumn("t3");
            dt.Columns.Add(dc);


            for(int i=1; i<=v; i++)
            {
                int z = dictWindowM[i];
                
                if(z == -1)
                {
                    listN1.Add(i);
                }
                else if(z == 0)
                {
                    listN2.Add(i);
                }
                else if(z==1)
                {
                    listN3.Add(i);
                }


            }
            

            for(int j=0; j<listN1.Count(); j++)
            {
                this.dataGrids1.Columns.Add(new DataGridTextColumn() { Header = listN1[j].ToString(), Width = 40 });
            }

            for (int j = 0; j < listN2.Count(); j++)
            {
                this.dataGrids2.Columns.Add(new DataGridTextColumn() { Header = listN2[j].ToString(), Width = 40 });
            }

            for (int j = 0; j < listN3.Count(); j++)
            {
                this.dataGrids3.Columns.Add(new DataGridTextColumn() { Header = listN3[j].ToString(), Width = 40 });
            }

        }


    }
}
