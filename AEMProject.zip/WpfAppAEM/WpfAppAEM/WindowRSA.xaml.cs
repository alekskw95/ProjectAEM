﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Numerics;


namespace WpfAppAEM
{
    /// <summary>
    /// Interaction logic for WindowRSA.xaml
    /// </summary>
    public partial class WindowRSA : Window
    {

        public WindowRSA()
        {
            InitializeComponent();


        }

        public byte[] EncryptM(string publicKeyXML, string dataToDycript)
        {
            RSACryptoServiceProvider rsa = new RSACryptoServiceProvider();
            rsa.FromXmlString(publicKeyXML);

            return rsa.Encrypt(ASCIIEncoding.ASCII.GetBytes(dataToDycript), true);
        }

        public string DecryptM(string publicPrivateKeyXML, byte[] encryptedData)
        {
            RSACryptoServiceProvider rsa = new RSACryptoServiceProvider();
            rsa.FromXmlString(publicPrivateKeyXML);

            return ASCIIEncoding.ASCII.GetString(rsa.Decrypt(encryptedData, true));
        }


        public byte[] encrypted;

        public void EncryptCode()
        {
            RSACryptoServiceProvider RSA = new RSACryptoServiceProvider();
            RSA.FromXmlString(TBtextPublicKey.Text);
            byte[] decrypted = System.Text.Encoding.Unicode.GetBytes(TBtext.Text);
            encrypted = RSA.Encrypt(decrypted, false);
            TBTextZakodowany.Text = System.Convert.ToBase64String(encrypted);
        }

        private void BtnRSAStartE_Click(object sender, RoutedEventArgs e) 
        {
            try
            {
                if(TBOdszyfrowanyKod.Text != "")
                {
                    TBOdszyfrowanyKod.Clear();
                    BtnRSAStart2.IsEnabled = false;

                    EncryptCode();

                    BtnRSAStart2.IsEnabled = true;
                }
                else
                {
                    EncryptCode();
                    BtnRSAStart2.IsEnabled = true;
                }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Nieprawidlowe dane !!!");
            }

        }

        private void BtnRSAStartD_Click(object sender, RoutedEventArgs e)
        {

            if (TBTextZakodowany.Text == "")
            {
                MessageBox.Show("Nieprawidlowe dane !!!");
            }
            else
            {
                CspParameters cspParam = new CspParameters();
                cspParam.Flags = CspProviderFlags.UseMachineKeyStore;
                RSACryptoServiceProvider RSA = new RSACryptoServiceProvider(cspParam);
                RSA.FromXmlString(TBtextPrivateKey.Text);
                byte[] decrypted = RSA.Decrypt(encrypted, false);
                TBOdszyfrowanyKod.Text = System.Text.Encoding.Unicode.GetString(decrypted);

                BtnRSAStart2.IsEnabled = false;
            }

        }

        private void BtnRSAClear_Click(object sender, RoutedEventArgs e)
        {
            TBtext.Clear();
            TBTextZakodowany.Clear();
            TBOdszyfrowanyKod.Clear();
            TBtext.Clear();
            TBtextPrivateKey.Clear();
            TBtextPublicKey.Clear();

            BtnRSAStart.IsEnabled = true;
            BtnRSAStart2.IsEnabled = false;
        }




        
        private void BtnRSAStartGenerator_Click(object sender, RoutedEventArgs e) 
        {
            TBtextPrivateKey.Clear();
            TBtextPublicKey.Clear();
            TBTextZakodowany.Clear();
    
            RSACryptoServiceProvider rsa = new RSACryptoServiceProvider(); 
            RSAParameters rsaKeyInfo = rsa.ExportParameters(false);
            string publicPrivateKeyXML = rsa.ToXmlString(true);
            TBtextPrivateKey.Text = publicPrivateKeyXML;
            string publicOnlyKeyXML = rsa.ToXmlString(false);
            TBtextPublicKey.Text = publicOnlyKeyXML;

        }

    }
}
